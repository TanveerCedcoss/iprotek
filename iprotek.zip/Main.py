import sys
import subprocess
import os.path as path

try:
    import eel
except:
   subprocess.check_call([sys.executable, "-m", "pip", "install", 'eel'])
   import eel

class Main:
    def __init__(self):
        self.log="./bright.conf"
        self.path="/home/cedcoss/.iprotek/web"
        self.index="index.html"

        eel.init(self.path)
    
    def start(self):
        size=(1400,750)
        position=(250,10)
        eel.start(self.index,size=size,position=position,port=0)

    def run(self,command,decode=True):
        if decode:
            commandList=command.split()
        else :
            commandList=command
        return subprocess.run(commandList,stdout=subprocess.PIPE).stdout.decode("utf-8").strip()

    def getDisplay(self):
        command='xrandr -q'
        res=self.run(command).split("\n")
        for i in res:
            if ' connected ' in i:
                res=i.split()[0]
        return res

    def getPref(self,key="False"):
        if not path.exists(self.log):
            return False
        if key=="False":
            props={}
            with open(self.log,"r") as logFile:
                buff=logFile.readline()
                while len(buff)>0:
                    if(buff != "\n"):
                        key=buff.split(":")[0]
                        val=buff.split(":")[1]
                        props[key]=val.strip()
                    buff=logFile.readline()
            return props
        else:
            with open(self.log,"r") as logFile:
                buff=logFile.readline()
                while len(buff)>0:
                    if key in buff:
                        return buff.split(":")[1].strip()
                    buff=logFile.readline()
        return False

    def setPref(self,key,val):
        if self.getPref(key) != False:
            keys=self.getPref()
            keys[key]=val
            with open(self.log,"w") as logFile:
                for i in keys.keys():
                    logFile.write(i+":"+keys[i]+"\n")
        else:
            with open(self.log,"a") as logFile:
                logFile.write(key+":"+val+"\n")
