// Brightness slider
// bright = $("#brightness").children("div").first().children("#range");
var bright = $("#brightnessRange");
//Gamma Switch
var gamma = $("#gammaSwitch");
// var  = $("#range");

//Dark Mode Switch
darkModeSwitch = $("#darkMode");

$(async function () {
  console.log(bright);
  value = await eel.getBrightness()();
  eel.setBrightness(value);
  bright.val(value);
  $("#current").html(value + "%");
  dark = (await eel.getTheme()()) == "dark";
  console.log(dark);
  setDarkTheme(dark);
});

bright.on("change", function () {
  val = $(this).val();
  eel.setBrightness(val);
  $("#brightness")
    .children("#current")
    .html(val + "%");
});

gamma.on("change", function () {
  if ($(this).is(":checked")) {
    green = 209;
    blue = 163;
    val = "1#" + green / 255 + "#" + blue / 255;
    eel.setGamma(val);
  } else {
    eel.setGamma("1#1#1");
  }
});

darkModeSwitch.on("change", async function () {
  setDarkTheme($(this).is(":checked"));
});

function setDarkTheme(val) {
  if (val) {
    $("body").addClass("bg-dark text-light");
    $("body").removeClass("bg-light text-dark");

    darkModeSwitch.attr("checked", "true");
    eel.setTheme("dark");
  } else {
    $("body").removeClass("bg-dark text-light");
    $("body").addClass("bg-light text-dark");
    eel.setTheme("light");
  }
}
$(".popup").hide();
$("#showPopup").on("click", function () {
  $(".popup").fadeIn("slow");
});

$(".popup button").on("click", function () {
  $(".popup").fadeOut("slow");
});
$("#modalBtn").click(function () {
  $("#myModal").modal("show");
});
