from Main import Main
import eel
def alterDisplay(brightness=None,gamma=None):
    display=main.getDisplay()
    if(not brightness):
        brightness=main.getPref("brightness") if int(main.getPref("brightness")) else "100"    
    if(not gamma):
        gamma=main.getPref("gamma") if main.getPref("gamma") else "1#1#1" 
        
    brightness=str(int(brightness)/100)
    gamma=gamma.replace("#",":")
    command="xrandr --output {name} --brightness {bright} --gamma {gamma}".format(name=display,bright=brightness,gamma=gamma)
    return main.run(command)

@eel.expose
def setBrightness(val):
    main.setPref("brightness",val if val else "100") 
    output=alterDisplay(brightness=val)

@eel.expose
def getBrightness():
    out = main.getPref("brightness")     
    return out

@eel.expose
def setGamma(val):
    main.setPref("gamma",val)
    val=val.replace("#",":")
    output=alterDisplay(gamma=val)

@eel.expose
def getGamma():
    out = main.getPref("gamma")  
    return out

@eel.expose
def getTheme():
    return main.getPref("theme") if main.getPref("theme") else "dark"

@eel.expose
def setTheme(theme):
    main.setPref("theme",theme)


main=Main()        
main.start()
